public class Entity1 extends Entity
{    
    // Perform any necessary initialization in the constructor
    public Entity1()
    {
    	int [] mic = new int[NetworkSimulator.NUMENTITIES];
    	for(int i = 0; i < NetworkSimulator.NUMENTITIES; i++)
    	{
    		for (int j = 0; j < NetworkSimulator.NUMENTITIES; j++)
    		{
    			if(i != j)
    			{
    				distanceTable[i][j] = 999;
    			}
    			else
    				distanceTable[i][j] = NetworkSimulator.cost[1][i];
    		}
    	}
    	for(int i = 0; i < NetworkSimulator.NUMENTITIES; i++)
    	{
    		mic[i] = distanceTable[i][i];
    	}
    	for(int i = 0; i<NetworkSimulator.NUMENTITIES; i++ )
    	{
    		Packet p = new Packet(1,i,mic);
    		NetworkSimulator.toLayer2(p);
    		
    	}
    	System.out.println("The initial contens of distanceTable of node 1 is");
    	this.printDT();
    }
    
    // Handle updates when a packet is received.  Students will need to call
    // NetworkSimulator.toLayer2() with new packets based upon what they
    // send to update.  Be careful to construct the source and destination of
    // the packet correctly.  Read the warning in NetworkSimulator.java for more
    // details.
    public void update(Packet p)
    {
    	int source = p.getSource();
    	int dest = p.getDest();
    	int mark = 0;
    	int[] old = new int[NetworkSimulator.NUMENTITIES];
    	int[] updating = new int[NetworkSimulator.NUMENTITIES];
    	int[] min = new int[NetworkSimulator.NUMENTITIES];
    	for (int i = 0; i < NetworkSimulator.NUMENTITIES; i++)
        {
             min[i] = p.getMincost(i);
        }
    	for (int i = 0; i < NetworkSimulator.NUMENTITIES; i++)
        {
        	old[i] = distanceTable[i][0];
        	for (int j = 0; j < NetworkSimulator.NUMENTITIES; j++)
        	{
        		if(old[i] > distanceTable[i][j])
        			old[i] = distanceTable[i][j];
        	}
        }
    	for (int i = 0; i < NetworkSimulator.NUMENTITIES; i++)
        {
    		distanceTable[i][source] = NetworkSimulator.cost[1][source] + min[i];
        }
    	for (int i = 0; i < NetworkSimulator.NUMENTITIES; i++)
        {
    		updating[i] = distanceTable[i][0];
    		for (int j = 0; j < NetworkSimulator.NUMENTITIES; j++)
         	{
         		if(updating[i] > distanceTable[i][j])
         			updating[i] = distanceTable[i][j];
         	}
        }
    	for (int i = 0; i < NetworkSimulator.NUMENTITIES; i++)
        {
        	if(updating[i]!=old[i])
        	{
        		mark = 1;
        	}
        }
    	if(mark == 1)
        {
    		Packet p1 = new Packet(1,0,updating);
        	Packet p2 = new Packet(1,2,updating);
        	NetworkSimulator.toLayer2(p1);	
        	NetworkSimulator.toLayer2(p2);
        }
    	System.out.println("The packet to "+dest+ " is from "+source);
    	System.out.println("The  contents of distanceTable of node 1 after updating is ");
    	this.printDT();
    }
    
    public void linkCostChangeHandler(int whichLink, int newCost)
    {
    	int[] old = new int[NetworkSimulator.NUMENTITIES];
    	int[] updating = new int[NetworkSimulator.NUMENTITIES];
    	int[] min0 = new int[NetworkSimulator.NUMENTITIES];
    	int[] min2 = new int[NetworkSimulator.NUMENTITIES];
    	int mark = 0;
    	min0[0] = 0;
    	min0[1] = distanceTable[0][0];
    	min0[2] = distanceTable[2][0] - min0[1];
    	min0[3] = distanceTable[3][0] - min0[1];
    	
    	min2[0] = distanceTable[0][2] - distanceTable[2][2];
    	min2[1] = distanceTable[2][2];
    	min2[2] = 0;
    	min2[3] = distanceTable[3][2] - distanceTable[2][2];
    	
    	
    	for (int i = 0; i < NetworkSimulator.NUMENTITIES; i++)
        {
    		old[i] = distanceTable[i][0];
        	for (int j = 0; j < NetworkSimulator.NUMENTITIES; j++)
        	{
        		if(old[i] > distanceTable[i][j])
        			old[i] = distanceTable[i][j];
        	}
        }
    	
    	for (int i = 0; i < NetworkSimulator.NUMENTITIES; i++)
        {
    		distanceTable[i][whichLink] = newCost + min0[i];
        }
    	for (int i = 0; i < NetworkSimulator.NUMENTITIES; i++)
        {
    		updating[i] = distanceTable[i][0];
    		for (int j = 0; j < NetworkSimulator.NUMENTITIES; j++)
         	{
         		if(updating[i] > distanceTable[i][j])
         			updating[i] = distanceTable[i][j];
         	}
        }
    	for (int i = 0; i < NetworkSimulator.NUMENTITIES; i++)
        {
        	if(updating[i]!=old[i])
        	{
        		mark = 1;
        	}
        }
    	if(mark == 1)
        {
    		Packet p1 = new Packet(1,0,updating);
        	Packet p2 = new Packet(1,2,updating);
        	
        	NetworkSimulator.toLayer2(p1);	
        	NetworkSimulator.toLayer2(p2);
        	
        }
    	
    	System.out.println("The  contens of distanceTable of node 1 after linkchange is ");
    	this.printDT();
    }
    
    public void printDT()
    {
        System.out.println();
        System.out.println("         via");
        System.out.println(" D1 |   0   2");
        System.out.println("----+--------");
        for (int i = 0; i < NetworkSimulator.NUMENTITIES; i++)
        {
            if (i == 1)
            {
                continue;
            }
            
            System.out.print("   " + i + "|");
            for (int j = 0; j < NetworkSimulator.NUMENTITIES; j += 2)
            {
            
                if (distanceTable[i][j] < 10)
                {    
                    System.out.print("   ");
                }
                else if (distanceTable[i][j] < 100)
                {
                    System.out.print("  ");
                }
                else 
                {
                    System.out.print(" ");
                }
                
                System.out.print(distanceTable[i][j]);
            }
            System.out.println();
        }
    }
}
