public class Entity0 extends Entity
{    
    // Perform any necessary initialization in the constructor
    public Entity0()
    {
    	int [] mic = new int[NetworkSimulator.NUMENTITIES];//the mincost from 0 to other nodes right now
	
    	for(int i = 0; i < NetworkSimulator.NUMENTITIES; i++)//initial
    	{
    		for (int j = 0; j < NetworkSimulator.NUMENTITIES; j++)
    		{
    			if(i != j)
    			{
    				distanceTable[i][j] = 999;
    			}
    			else
    				distanceTable[i][j] = NetworkSimulator.cost[0][i];
    		}
    	}
    	for(int i = 0; i < NetworkSimulator.NUMENTITIES; i++)//find the mincost
    	{
    		mic[i] = distanceTable[i][i];
    	}
    	for(int i = 0; i<NetworkSimulator.NUMENTITIES; i++ )//tolayer2
    	{
    		Packet p = new Packet(0,i,mic);
    		NetworkSimulator.toLayer2(p);
    		
    	}
    	System.out.println("The initial contents of distanceTable of node 0 is");
    	this.printDT();
    		
    	
    }
    
    // Handle updates when a packet is received.  Students will need to call
    // NetworkSimulator.toLayer2() with new packets based upon what they
    // send to update.  Be careful to construct the source and destination of
    // the packet correctly.  Read the warning in NetworkSimulator.java for more
    // details.
    public void update(Packet p)
    { 
    	int source = p.getSource();
    	int dest = p.getDest();
    	int mark = 0;
    	int[] old = new int[NetworkSimulator.NUMENTITIES];//old mincost
    	int[] updating = new int[NetworkSimulator.NUMENTITIES];//new mincost after changing the table
    	int[] min = new int[NetworkSimulator.NUMENTITIES];
    	for (int i = 0; i < NetworkSimulator.NUMENTITIES; i++)//store the packet information
        {
             min[i] = p.getMincost(i);
        }
    	for (int i = 0; i < NetworkSimulator.NUMENTITIES; i++)//find the mincost before updating
        {
        	old[i] = distanceTable[i][0];
        	for (int j = 0; j < NetworkSimulator.NUMENTITIES; j++)
        	{
        		if(old[i] > distanceTable[i][j])
        			old[i] = distanceTable[i][j];
        	}
        }
    	for (int i = 0; i < NetworkSimulator.NUMENTITIES; i++)//update the table 
        {
    		distanceTable[i][source] = NetworkSimulator.cost[0][source] + min[i];
        }
    	for (int i = 0; i < NetworkSimulator.NUMENTITIES; i++)//find the new mincost
        {
    		updating[i] = distanceTable[i][0];
    		for (int j = 0; j < NetworkSimulator.NUMENTITIES; j++)
         	{
         		if(updating[i] > distanceTable[i][j])
         			updating[i] = distanceTable[i][j];
         	}
        }
    	for (int i = 0; i < NetworkSimulator.NUMENTITIES; i++)//if the mincost changes, let mark = 1
        {
        	if(updating[i]!=old[i])
        	{
        		mark = 1;
        	}
        }
    	if(mark == 1)//tolayer2
        {
    		Packet p1 = new Packet(0,1,updating);
        	Packet p2 = new Packet(0,2,updating);
        	Packet p3 = new Packet(0,3,updating);
        	NetworkSimulator.toLayer2(p1);	
        	NetworkSimulator.toLayer2(p2);
        	NetworkSimulator.toLayer2(p3);
        }
    	System.out.println("The packet to "+dest+ " is from "+source);
    	System.out.println("The  contens of distanceTable of node 0 after updating is ");
    	this.printDT();
    }
    
    public void linkCostChangeHandler(int whichLink, int newCost)
    {
    	int[] min0 = new int[NetworkSimulator.NUMENTITIES];
    	int[] updating = new int[NetworkSimulator.NUMENTITIES];
    	int[] min1 = new int[NetworkSimulator.NUMENTITIES];
    	int[] min2 = new int[NetworkSimulator.NUMENTITIES];
    	int[] min3 = new int[NetworkSimulator.NUMENTITIES];
    	int mark = 0;
    	min1[0] = distanceTable[1][1];//they are used for updating the table after link changes.
    	min1[1] = 0;
    	min1[2] = distanceTable[2][1] - min1[0];
    	min1[3] = distanceTable[3][1] - min1[0];
   
    	min2[0] = distanceTable[2][2];
    	min2[1] = distanceTable[1][2] - min2[0];
    	min2[2] = 0;
    	min2[3] = distanceTable[3][2] - min2[0];
    	
    	min3[0] = distanceTable[3][3];
    	min3[1] = distanceTable[1][3] - min3[0];
    	min3[2] = distanceTable[2][3] - min3[0];
    	min3[3] = 0;
    	
    	for (int i = 0; i < NetworkSimulator.NUMENTITIES; i++)//mincost before linkchange happens
        {
        	min0[i] = distanceTable[i][0];
        	for (int j = 0; j < NetworkSimulator.NUMENTITIES; j++)
        	{
        		if(min0[i] > distanceTable[i][j])
        			min0[i] = distanceTable[i][j];
        	}
        }
    	
    	for (int i = 0; i < NetworkSimulator.NUMENTITIES; i++)//because cost[0][1] changes, we need to update distanceTable[i][1]
        {
    		distanceTable[i][whichLink] = newCost + min1[i];
        }
    	for (int i = 0; i < NetworkSimulator.NUMENTITIES; i++)//find the mincost after updating
        {
    		updating[i] = distanceTable[i][0];
    		for (int j = 0; j < NetworkSimulator.NUMENTITIES; j++)
         	{
         		if(updating[i] > distanceTable[i][j])
         			updating[i] = distanceTable[i][j];
         	}
        }
    	for (int i = 0; i < NetworkSimulator.NUMENTITIES; i++)//if mincost changes then mark = 1
        {
        	if(updating[i]!=min0[i])
        	{
        		mark = 1;
        	}
        }
    	if(mark == 1)//tolayer2 ,send the updates to its neighbors.
        {
    		Packet p1 = new Packet(0,1,updating);
        	Packet p2 = new Packet(0,2,updating);
        	Packet p3 = new Packet(0,3,updating);
        	NetworkSimulator.toLayer2(p1);	
        	NetworkSimulator.toLayer2(p2);
        	NetworkSimulator.toLayer2(p3);
        }
    	System.out.println("The  contens of distanceTable of node 0 after linkchange is ");
    	this.printDT();
    }
    
    public void printDT()
    {
        System.out.println();
        System.out.println("           via");
        System.out.println(" D0 |   1   2   3");
        System.out.println("----+------------");
        for (int i = 1; i < NetworkSimulator.NUMENTITIES; i++)
        {
            System.out.print("   " + i + "|");
            for (int j = 1; j < NetworkSimulator.NUMENTITIES; j++)
            {
                if (distanceTable[i][j] < 10)
                {    
                    System.out.print("   ");
                }
                else if (distanceTable[i][j] < 100)
                {
                    System.out.print("  ");
                }
                else 
                {
                    System.out.print(" ");
                }
                
                System.out.print(distanceTable[i][j]);
            }
            System.out.println();
        }
    }
}
